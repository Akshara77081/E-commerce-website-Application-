require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

const User = mongoose.model("User", new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true, lowercase: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["user", "admin"], default: "user" }
}, { timestamps: true }));

const Product = mongoose.model("Product", new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  price: { type: Number, required: true },
  category: String,
  image: String,
  stock: { type: Number, default: 10 }
}, { timestamps: true }));

const Order = mongoose.model("Order", new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
    name: String,
    price: Number,
    quantity: Number
  }],
  total: Number,
  address: String,
  status: { type: String, enum: ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"], default: "Placed" }
}, { timestamps: true }));

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace("Bearer ", "");
  if (!token) return res.status(401).json({ message: "Authentication required" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid or expired token" });
  }
}
function admin(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ message: "Admin access required" });
  next();
}

app.get("/api/health", (req, res) => res.json({ ok: true, service: "Thiranex E-Commerce API" }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: "All fields are required" });
    if (await User.findOne({ email })) return res.status(409).json({ message: "Email already registered" });
    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hash });
    res.status(201).json({ message: "Registration successful", user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ message: "Invalid email or password" });
    const token = jwt.sign({ id: user._id, name: user.name, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

app.get("/api/products", async (req, res) => {
  const filter = {};
  if (req.query.category && req.query.category !== "All") filter.category = req.query.category;
  if (req.query.search) filter.name = { $regex: req.query.search, $options: "i" };
  res.json(await Product.find(filter).sort({ createdAt: -1 }));
});

app.get("/api/products/:id", async (req, res) => {
  try { res.json(await Product.findById(req.params.id)); }
  catch { res.status(404).json({ message: "Product not found" }); }
});

app.post("/api/products", auth, admin, async (req, res) => {
  try { res.status(201).json(await Product.create(req.body)); }
  catch (e) { res.status(400).json({ message: e.message }); }
});

app.put("/api/products/:id", auth, admin, async (req, res) => {
  try { res.json(await Product.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true })); }
  catch (e) { res.status(400).json({ message: e.message }); }
});

app.delete("/api/products/:id", auth, admin, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ message: "Product deleted" });
});

app.post("/api/orders", auth, async (req, res) => {
  try {
    const { items, address } = req.body;
    if (!items?.length || !address) return res.status(400).json({ message: "Cart and address are required" });
    const ids = items.map(x => x.product);
    const products = await Product.find({ _id: { $in: ids } });
    const normalized = items.map(x => {
      const p = products.find(y => String(y._id) === String(x.product));
      if (!p) throw new Error("Product not found");
      if (p.stock < x.quantity) throw new Error(`Insufficient stock for ${p.name}`);
      return { product: p._id, name: p.name, price: p.price, quantity: x.quantity };
    });
    const total = normalized.reduce((s, x) => s + x.price * x.quantity, 0);
    for (const x of normalized) await Product.findByIdAndUpdate(x.product, { $inc: { stock: -x.quantity } });
    const order = await Order.create({ user: req.user.id, items: normalized, total, address });
    res.status(201).json(order);
  } catch (e) { res.status(400).json({ message: e.message }); }
});

app.get("/api/orders/my", auth, async (req, res) => {
  res.json(await Order.find({ user: req.user.id }).sort({ createdAt: -1 }));
});

app.get("/api/orders", auth, admin, async (req, res) => {
  res.json(await Order.find().populate("user", "name email").sort({ createdAt: -1 }));
});

app.put("/api/orders/:id/status", auth, admin, async (req, res) => {
  const allowed = ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ message: "Invalid status" });
  res.json(await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true }));
});

async function start() {
  await mongoose.connect(process.env.MONGODB_URI);
  app.listen(process.env.PORT || 5000, () => console.log(`API running on port ${process.env.PORT || 5000}`));
}
start().catch(err => { console.error(err); process.exit(1); });
