require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const fs = require("fs");

const userSchema = new mongoose.Schema({
  name: String, email: { type: String, unique: true }, password: String, role: String
});
const productSchema = new mongoose.Schema({
  name: String, description: String, price: Number, category: String, image: String, stock: Number
});
const User = mongoose.model("User", userSchema);
const Product = mongoose.model("Product", productSchema);

const products = [
  {name:"Classic T-Shirt", description:"Comfortable cotton everyday t-shirt.", price:599, category:"Fashion", image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800", stock:25},
  {name:"Running Shoes", description:"Lightweight shoes for daily training.", price:1499, category:"Footwear", image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800", stock:18},
  {name:"Smart Watch", description:"Fitness and notification smart watch.", price:2499, category:"Electronics", image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800", stock:12},
  {name:"Backpack", description:"Durable laptop backpack for college and work.", price:999, category:"Accessories", image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800", stock:20},
  {name:"Wireless Headphones", description:"Over-ear wireless headphones.", price:1999, category:"Electronics", image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800", stock:15},
  {name:"Denim Jacket", description:"Classic denim jacket with modern fit.", price:1799, category:"Fashion", image:"https://images.unsplash.com/photo-1543076447-215ad9ba6923?w=800", stock:10}
];

(async()=>{
  await mongoose.connect(process.env.MONGODB_URI);
  const pass = await bcrypt.hash("Admin@123", 10);
  await User.findOneAndUpdate(
    {email:"admin@thiranex.com"},
    {name:"Thiranex Admin", email:"admin@thiranex.com", password:pass, role:"admin"},
    {upsert:true, new:true}
  );
  await Product.deleteMany({});
  await Product.insertMany(products);
  console.log("Seed complete.");
  await mongoose.disconnect();
})().catch(e=>{console.error(e);process.exit(1)});
