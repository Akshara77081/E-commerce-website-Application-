# Thiranex E-Commerce Web Application

A full-stack e-commerce project prepared for the Thiranex Internship E-Commerce Web Application task.

## Features
- User registration and login
- Admin and User roles
- Product catalog
- Search and category filtering
- Add to cart and quantity updates
- Checkout and order creation
- User order history
- Admin product CRUD
- Admin order status management
- Responsive frontend
- REST API backend
- MongoDB database integration

## Tech Stack
- Frontend: HTML, CSS, Vanilla JavaScript
- Backend: Node.js + Express.js
- Database: MongoDB
- Authentication: JWT + bcrypt
- Deployment-ready for Render (backend) and Netlify/Vercel (frontend)

## Run locally
1. Install Node.js and MongoDB.
2. Open `backend`.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and update values.
5. Run `npm run seed`.
6. Run `npm start`.
7. Open `frontend/index.html` with a local static server.

Demo admin:
- Email: admin@thiranex.com
- Password: Admin@123

Change the password before using the application publicly.

## Deployment
The project is structured so the backend can be deployed to Render and the frontend to Netlify or Vercel. Set the frontend API URL to the deployed backend URL before publishing.
