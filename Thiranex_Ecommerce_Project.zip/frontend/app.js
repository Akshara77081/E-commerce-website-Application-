const API = localStorage.getItem("API_URL") || "http://localhost:5000/api";
let products=[], cart=JSON.parse(localStorage.getItem("cart")||"[]"), category="All";

const $=id=>document.getElementById(id);
function token(){return localStorage.getItem("token")}
function user(){return JSON.parse(localStorage.getItem("user")||"null")}
function money(n){return "₹"+Number(n).toLocaleString("en-IN")}
function updateCart(){ $("cartCount").textContent=cart.reduce((s,x)=>s+x.quantity,0); localStorage.setItem("cart",JSON.stringify(cart)); }

async function loadProducts(){
  const q=$("search").value;
  const r=await fetch(`${API}/products?search=${encodeURIComponent(q)}&category=${encodeURIComponent(category)}`);
  products=await r.json(); renderProducts();
}
function renderProducts(){
  $("productGrid").innerHTML=products.map(p=>`<article class="card">
  <img src="${p.image||'https://via.placeholder.com/600x400'}" alt="${p.name}">
  <div class="card-body"><h3>${p.name}</h3><p>${p.description||''}</p><div class="price">${money(p.price)}</div>
  <small>${p.stock>0?p.stock+" available":"Out of stock"}</small>
  <button class="primary" ${p.stock<1?'disabled':''} onclick="addCart('${p._id}')">Add to Cart</button></div></article>`).join("");
  const cats=["All",...new Set(products.map(p=>p.category).filter(Boolean))];
  $("categories").innerHTML=cats.map(c=>`<button class="chip ${c===category?'active':''}" onclick="setCategory('${c}')">${c}</button>`).join("");
}
function setCategory(c){category=c;loadProducts()}
function addCart(id){
  const p=products.find(x=>x._id===id), old=cart.find(x=>x.product===id);
  if(old) old.quantity++; else cart.push({product:id,name:p.name,price:p.price,quantity:1});
  updateCart(); alert("Added to cart");
}
function closeModal(){$("modal").classList.add("hidden")}
function show(html){$("modalContent").innerHTML=html;$("modal").classList.remove("hidden")}

$("search").addEventListener("input",loadProducts);
$("cartBtn").onclick=()=>showCart();
$("loginBtn").onclick=()=>token()?showProfile():showLogin();

function showLogin(){show(`<h2>Login</h2><form class="form" id="loginForm">
<input id="email" type="email" placeholder="Email" required><input id="password" type="password" placeholder="Password" required>
<button class="primary">Login</button><p>New user? <a href="#" onclick="showRegister();return false">Create account</a></p></form>`);
$("loginForm").onsubmit=async e=>{e.preventDefault();const r=await fetch(API+"/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:email.value,password:password.value})});const d=await r.json();if(!r.ok)return alert(d.message);localStorage.setItem("token",d.token);localStorage.setItem("user",JSON.stringify(d.user));closeModal();updateHeader();}}
function showRegister(){show(`<h2>Create Account</h2><form class="form" id="regForm"><input id="name" placeholder="Full name" required><input id="email" type="email" placeholder="Email" required><input id="password" type="password" placeholder="Password" required><button class="primary">Register</button><p>Already registered? <a href="#" onclick="showLogin();return false">Login</a></p></form>`);
$("regForm").onsubmit=async e=>{e.preventDefault();const r=await fetch(API+"/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:name.value,email:email.value,password:password.value})});const d=await r.json();if(!r.ok)return alert(d.message);alert("Registration successful. Please login.");showLogin();}}
function showProfile(){const u=user();show(`<h2>Hello, ${u.name}</h2><p>${u.email}</p><p>Role: <b>${u.role}</b></p><button class="outline" onclick="localStorage.clear();cart=[];updateCart();closeModal();updateHeader()">Logout</button>`)}
function updateHeader(){$("loginBtn").textContent=token()?"Account":"Login"}

function showCart(){
 let total=cart.reduce((s,x)=>s+x.price*x.quantity,0);
 show(`<h2>Your Cart</h2>${cart.length?cart.map((x,i)=>`<div class="order"><b>${x.name}</b><br>${money(x.price)} × <input style="width:60px" type="number" min="1" value="${x.quantity}" onchange="cart[${i}].quantity=+this.value;updateCart();showCart()"> = ${money(x.price*x.quantity)} <button onclick="cart.splice(${i},1);updateCart();showCart()">Remove</button></div>`).join("")+`<h3>Total: ${money(total)}</h3><button class="primary" onclick="checkout()">Checkout</button>`:"<p>Your cart is empty.</p>"}`);
}
function checkout(){
 if(!token()){showLogin();return}
 show(`<h2>Checkout</h2><form class="form" id="checkoutForm"><textarea id="address" placeholder="Delivery address" required></textarea><button class="primary">Place Order</button></form>`);
 $("checkoutForm").onsubmit=async e=>{e.preventDefault();const r=await fetch(API+"/orders",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+token()},body:JSON.stringify({items:cart,address:address.value})});const d=await r.json();if(!r.ok)return alert(d.message);cart=[];updateCart();closeModal();loadOrders();alert("Order placed successfully!")};
}
async function loadOrders(){
 if(!token()){$("orders").classList.add("hidden");return}
 $("orders").classList.remove("hidden");
 const r=await fetch(API+"/orders/my",{headers:{Authorization:"Bearer "+token()}});const data=await r.json();
 $("ordersList").innerHTML=data.length?data.map(o=>`<div class="order"><b>Order #${o._id.slice(-8)}</b><br>Total: ${money(o.total)}<br>Status: <b>${o.status}</b><br><small>${new Date(o.createdAt).toLocaleString()}</small></div>`).join(""):"<p>No orders yet.</p>";
}
updateCart();updateHeader();loadProducts();loadOrders();